import { Link, Head } from "@inertiajs/react";

export default function permitiondenied() {
    return (
        <>
            <Head title="Permisions not granted"/>
            Sorry! You can't do or access because you are not authorize to do or access. If you think this is wrong stuation, Contact Adminstator!
        </>
    );
}
