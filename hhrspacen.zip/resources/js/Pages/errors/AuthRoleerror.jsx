import { Link, Head } from "@inertiajs/react";

export default function AuthRoleerror() {
    return (
        <>
            <Head title="AUthenication Error"/>
            Something went wrong with your account. Contact Administration!
        </>
    );
}
