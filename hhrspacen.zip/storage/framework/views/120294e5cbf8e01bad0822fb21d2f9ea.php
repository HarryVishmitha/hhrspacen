<?php echo e($slot); ?>

<?php /**PATH D:\server\htdocs\hhrspacen\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>