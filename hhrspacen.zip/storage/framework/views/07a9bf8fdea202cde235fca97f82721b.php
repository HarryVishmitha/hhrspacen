<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH D:\server\htdocs\hhrspacen\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>